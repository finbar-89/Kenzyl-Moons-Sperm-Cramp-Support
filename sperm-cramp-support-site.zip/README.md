# Completely Serious Sperm Cramp Support Centre

A small anonymous New Zealand health-information webpage.

## Publish free with GitHub Pages

1. Sign in to GitHub.
2. Click **New repository**.
3. Give it a neutral name such as `cramp-support`.
4. Choose **Public**, then create the repository.
5. Click **Add file → Upload files**.
6. Upload `index.html` and `style.css` from this folder.
7. Commit the files.
8. Open the repository's **Settings → Pages**.
9. Under **Build and deployment**, choose **Deploy from a branch**.
10. Select `main` and `/ (root)`, then click **Save**.
11. Wait a few minutes. GitHub will show the published address in the Pages section.

The page deliberately does not contain the name, school, or identifying information of any individual.

Important: verify health-service contact details before publishing and periodically thereafter.
